from segregation import aspatial
from segregation import spatial
from segregation import inference
from segregation import decomposition
from segregation import util
from segregation import network
from segregation import local
from segregation import compute_all
