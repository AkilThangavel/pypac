from inequality import theil
from inequality import gini
